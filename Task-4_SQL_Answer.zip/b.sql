SELECT i.InvoiceNo, i.StockCode, i.Description, i.Quantity, i.UnitPrice,
       c.CustomerName, c.Country
FROM Invoices i
INNER JOIN Customers c
ON i.CustomerID = c.CustomerID;


SELECT i.InvoiceNo, i.StockCode, i.Description, i.Quantity, i.UnitPrice,
       c.CustomerName, c.Country
FROM Invoices i
LEFT JOIN Customers c
ON i.CustomerID = c.CustomerID;



SELECT i.InvoiceNo, i.StockCode, i.Description, i.Quantity, i.UnitPrice,
       c.CustomerName, c.Country
FROM Invoices i
RIGHT JOIN Customers c
ON i.CustomerID = c.CustomerID;