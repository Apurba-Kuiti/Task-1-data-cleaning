CREATE OR REPLACE VIEW CustomerRevenue AS
SELECT c.CustomerName, c.Country, SUM(i.Quantity * i.UnitPrice) AS TotalRevenue
FROM Invoices i
INNER JOIN Customers c
ON i.CustomerID = c.CustomerID
GROUP BY c.CustomerName, c.Country;