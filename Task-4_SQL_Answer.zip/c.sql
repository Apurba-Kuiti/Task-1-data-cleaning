SELECT InvoiceNo, StockCode, Description, UnitPrice
FROM Invoices
WHERE UnitPrice > (
    SELECT AVG(UnitPrice)
    FROM Invoices
);