SELECT 
    Country, 
    StockCode, 
    SUM(Quantity) AS TotalQuantity, 
    AVG(UnitPrice) AS AvgPrice
FROM 
    Invoices
WHERE 
    Quantity >= 5      -- only include rows where quantity is 5 or more
GROUP BY 
    Country, StockCode
ORDER BY 
    Country ASC, TotalQuantity DESC;