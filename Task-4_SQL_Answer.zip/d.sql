SELECT c.CustomerName, SUM(i.Quantity * i.UnitPrice) AS TotalRevenue, AVG(i.UnitPrice) AS AvgUnitPrice
FROM Invoices i
INNER JOIN Customers c
ON i.CustomerID = c.CustomerID
GROUP BY c.CustomerName
ORDER BY TotalRevenue DESC;