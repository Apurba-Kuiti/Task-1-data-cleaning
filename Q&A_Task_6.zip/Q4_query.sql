SELECT 
    product_id,
    SUM(amount) AS total_sales
FROM orders
GROUP BY product_id
ORDER BY total_sales DESC;