SELECT * 
FROM orders
WHERE order_date BETWEEN TO_DATE('2023-01-01', 'YYYY-MM-DD') 
                    AND TO_DATE('2023-03-31', 'YYYY-MM-DD')
ORDER BY order_date;